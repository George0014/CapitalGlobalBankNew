import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function App() {
  const [page, setPage] = useState("home");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loggedIn, setLoggedIn] = useState(false);
  const [withdrawStep, setWithdrawStep] = useState(0);

  const handleLogin = () => {
    if (username === "Andre312" && password === "Dre4u") {
      setLoggedIn(true);
      setPage("dashboard");
    } else {
      alert("Invalid credentials. Please try again.");
    }
  };

  const renderHome = () => (
    <div className="min-h-screen bg-gradient-to-br from-blue-100 to-white flex flex-col items-center justify-center">
      <div className="bg-white p-8 rounded-2xl shadow-xl w-full max-w-md">
        <h1 className="text-3xl font-bold text-center text-blue-800 mb-6">Capital Global Bank</h1>
        <Input 
          placeholder="Username" 
          value={username} 
          onChange={e => setUsername(e.target.value)} 
          className="mb-4"
        />
        <Input 
          placeholder="Password" 
          type="password" 
          value={password} 
          onChange={e => setPassword(e.target.value)} 
          className="mb-6"
        />
        <Button className="w-full" onClick={handleLogin}>Login</Button>
        <p className="text-sm text-center mt-4 text-gray-500">Don't have an account? <span className="text-blue-600 cursor-pointer">Sign Up</span></p>
      </div>
    </div>
  );

  const renderDashboard = () => (
    <div className="min-h-screen p-8 bg-gray-100">
      <div className="max-w-4xl mx-auto bg-white rounded-2xl shadow-md p-6">
        <h1 className="text-3xl font-bold text-blue-800 mb-4">Welcome, Andre</h1>
        <p className="mb-2 text-lg">Account Balance: <span className="font-semibold text-green-700">$30,000,000</span></p>
        <p className="mb-6 text-lg">Withdrawable Balance: <span className="font-semibold text-yellow-600">$28,934,089</span></p>
        <div className="space-x-4">
          <Button onClick={() => setPage("withdraw")} className="bg-yellow-500 hover:bg-yellow-600">Withdraw</Button>
          <Button variant="secondary" onClick={() => setPage("home")}>Logout</Button>
        </div>
      </div>
    </div>
  );

  const renderWithdraw = () => {
    if (withdrawStep === 0) {
      return (
        <div className="min-h-screen flex items-center justify-center bg-yellow-50">
          <div className="bg-white p-8 rounded-2xl shadow-md w-full max-w-md">
            <h2 className="text-2xl font-bold mb-4 text-yellow-700">Withdraw Funds</h2>
            <Input placeholder="Enter Amount" className="mb-4" />
            <div className="space-x-4">
              <Button onClick={() => setWithdrawStep(1)} className="bg-yellow-600 hover:bg-yellow-700">Proceed</Button>
              <Button variant="secondary" onClick={() => setPage("dashboard")}>Cancel</Button>
            </div>
          </div>
        </div>
      );
    } else {
      return (
        <div className="min-h-screen flex items-center justify-center bg-red-100">
          <div className="bg-white p-8 rounded-2xl shadow-md w-full max-w-md text-center">
            <h2 className="text-2xl font-bold text-red-700 mb-4">Authorization Code Needed</h2>
            <p className="mb-6 text-gray-700">To complete your withdrawal, you must enter a valid Authorization Code.</p>
            <p className="font-semibold text-red-600 mb-6">Please contact your account officer.</p>
            <Input placeholder="Enter Authorization Code" className="mb-4" />
            <div className="space-x-4">
              <Button variant="destructive">Submit</Button>
              <Button variant="secondary" onClick={() => setPage("dashboard")}>Back to Dashboard</Button>
            </div>
          </div>
        </div>
      );
    }
  };

  if (!loggedIn) return renderHome();
  if (page === "dashboard") return renderDashboard();
  if (page === "withdraw") return renderWithdraw();
}